package com.example.sendox33;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ViewContacts extends AppCompatActivity {
    private Button sendButton;
    private EditText UserName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contacts);
        sendButton =(Button) findViewById(R.id.searchButton);
        UserName = (EditText) findViewById(R.id.contactToSearch);;
    }
}
