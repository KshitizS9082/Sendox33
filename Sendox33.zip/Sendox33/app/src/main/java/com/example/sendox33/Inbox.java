package com.example.sendox33;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class Inbox extends AppCompatActivity {
    private Button[] myInboxButtons = new Button[10];
    private Button prevButton;
    private Button nextButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox);
        myInboxButtons[0] = (Button)findViewById(R.id.button);
        myInboxButtons[1] = (Button)findViewById(R.id.button2);
        myInboxButtons[2] = (Button)findViewById(R.id.button3);
        myInboxButtons[3] = (Button)findViewById(R.id.button4);
        myInboxButtons[4] = (Button)findViewById(R.id.button5);
        myInboxButtons[5] = (Button)findViewById(R.id.button6);
        myInboxButtons[6] = (Button)findViewById(R.id.button7);
        myInboxButtons[7] = (Button)findViewById(R.id.button8);
        myInboxButtons[8] = (Button)findViewById(R.id.button9);
        myInboxButtons[9] = (Button)findViewById(R.id.button10);
        prevButton = (Button)findViewById(R.id.previousPageButton);
        nextButton = (Button)findViewById(R.id.nextPageButton);

    }

    void setButtonText(int buttonIndex, int pageIndex, String Sender, String preview){
        String text = Sender + " : " + preview;
        myInboxButtons[buttonIndex].setText(text);
//        myInboxButtons[buttonIndex].setTextAlignment();
    }
}
